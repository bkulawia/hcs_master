About CRHC-CLI
==============

This project contains the ``crhc`` command line tool that simplifies the use of the C.RH.C API available at console.redhat.com.
