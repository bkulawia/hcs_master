conf package
============

Submodules
----------

conf.conf module
----------------

.. automodule:: conf.conf
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: conf
   :members:
   :undoc-members:
   :show-inheritance:
