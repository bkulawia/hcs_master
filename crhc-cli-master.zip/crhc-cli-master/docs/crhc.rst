crhc module
===========

.. automodule:: crhc
   :members:
   :undoc-members:
   :show-inheritance:
