#!/usr/bin/env python
"""
TODO
"""


from parse import parse

if __name__ == "__main__":
    parse.main()
